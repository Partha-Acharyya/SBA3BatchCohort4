package com.wf.sba3.ibs.Entity;

public class CheckCCStatus {
	

	private static String ReferenceID;
	
	private static long MobileNumber;
	
	private static String Email;
	public static String getReferenceID() {
		return ReferenceID;
	}

	public static long getMobileNumber() {
		return MobileNumber;
	}

	public static String getEmail() {
		return Email;
	}
}
