package com.wf.sba3.ibs.Entity;

public class serviceproviderdetails {
	private String providername;
	private String member1;
	private String member2;
	private double networth;
	private double expectednetworth;
	private String pan;
	private String currentaccountnumber;
	private String currentacccountbranch;
	private String currentacccountifsccode;
	private String currentacccountname;
	private String phonenumber;
	private int SPI;
	public String getProvidername() {
		return providername;
	}
	public void setProvidername(String providername) {
		this.providername = providername;
	}
	public String getMember1() {
		return member1;
	}
	public void setMember1(String member1) {
		this.member1 = member1;
	}
	public String getMember2() {
		return member2;
	}
	public void setMember2(String member2) {
		this.member2 = member2;
	}
	public double getNetworth() {
		return networth;
	}
	public void setNetworth(double networth) {
		this.networth = networth;
	}
	public double getExpectednetworth() {
		return expectednetworth;
	}
	public void setExpectednetworth(double expectednetworth) {
		this.expectednetworth = expectednetworth;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getCurrentaccountnumber() {
		return currentaccountnumber;
	}
	public void setCurrentaccountnumber(String currentaccountnumber) {
		this.currentaccountnumber = currentaccountnumber;
	}
	public String getCurrentacccountbranch() {
		return currentacccountbranch;
	}
	public void setCurrentacccountbranch(String currentacccountbranch) {
		this.currentacccountbranch = currentacccountbranch;
	}
	public String getCurrentacccountifsccode() {
		return currentacccountifsccode;
	}
	public void setCurrentacccountifsccode(String currentacccountifsccode) {
		this.currentacccountifsccode = currentacccountifsccode;
	}
	public String getCurrentacccountname() {
		return currentacccountname;
	}
	public void setCurrentacccountname(String currentacccountname) {
		this.currentacccountname = currentacccountname;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public int getSPI() {
		return SPI;
	}
	public void setSPI(int sPI) {
		SPI = sPI;
	}
	
}
