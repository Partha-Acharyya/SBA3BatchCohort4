package com.wf.sba3.ibs.doa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.wf.sba3.ibs.Entity.CreditCardEligibility;



public class CreditcardEligibilityDao 
{

	private String driverName;
	private String url;
	private String username;
	private String password;
	
	private Connection connection;
	
	public CreditcardEligibilityDao(String driverName, String url, String username, String password,
			Connection connection) {
		super();
		this.driverName = driverName;
		this.url = url;
		this.username = username;
		this.password = password;
		this.connection = connection;
	}

	private void connect() throws ClassNotFoundException, SQLException {
		if(this.connection == null || this.connection.isClosed()) {
			Class.forName(this.driverName);
			this.connection = DriverManager.getConnection(this.url,this.username,this.password);
		}
	}
	
	private void disConnect() throws SQLException {
		if(this.connection!=null && !this.connection.isClosed())
		{
			this.connection.close();
	}
	}
		/*connection.PreparedStatement(""
				+ "insert into cc_eligibility(ReferenceID,FirstName,LastName,birthday,MobileNumber
				+ "birthday 
				+ "MobileNumber mediumtext \r\n"
				+ "TypeOfEmployment varchar(255) \r\n"
				+ "TotalIncome mediumtext \r\n"
				+ "Email"
				+ ""
				
				); 
		
	this.disConnect();
	return result;
	*/
	
		
	
	
}
	

