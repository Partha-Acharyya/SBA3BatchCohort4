package com.wf.sba3.ibs.servlet;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wf.sba3.ibs.Entity.CreditCardEligibility;

/**
 * Servlet implementation class CardManagement
 */
@WebServlet("/CardManagement")
public class CardManagement extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CardManagement() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String FirstName = request.getParameter("FirstName");
		String LastName = request.getParameter("LastName");
		String MobileNumber = request.getParameter("MobileNumber");
		String TypeOfEmployment = request.getParameter("TypeOfEmployment");
		String TotalIncome = request.getParameter("TotalIncome");
		String Email = request.getParameter("Email");
		String birthday = request.getParameter("birthday");
		
		CreditCardEligibility C = new CreditCardEligibility(FirstName, LastName, MobileNumber, TypeOfEmployment, TotalIncome, Email, birthday);
		request.setAttribute("CreditCardEligibility", C);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("CCEligibility_Success.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
				doGet(request, response);
	}
	

}
