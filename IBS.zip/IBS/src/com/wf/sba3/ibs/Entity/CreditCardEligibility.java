package com.wf.sba3.ibs.Entity;

import java.util.UUID;

public class CreditCardEligibility {
	private String FirstName;
	private String LastName;
	private String MobileNumber;
	private String TypeOfEmployment;
	private String TotalIncome;
	private String Email;
	private String birthday;

	public CreditCardEligibility(String firstName, String lastName, String mobileNumber, String typeOfEmployment,
			String totalIncome, String email, String birthday) {
		super();
		FirstName = firstName;
		LastName = lastName;
		MobileNumber = mobileNumber;
		TypeOfEmployment = typeOfEmployment;
		TotalIncome = totalIncome;
		Email = email;
		this.birthday = birthday;
	}
	
	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getMobileNumber() {
		return MobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		MobileNumber = mobileNumber;
	}

	public String getTypeOfEmployment() {
		return TypeOfEmployment;
	}

	public void setTypeOfEmployment(String typeOfEmployment) {
		TypeOfEmployment = typeOfEmployment;
	}

	public String getTotalIncome() {
		return TotalIncome;
	}

	public void setTotalIncome(String totalIncome) {
		TotalIncome = totalIncome;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public  String generateReferenceID() {
		 String ReferenceID = "";
		 try {
		 UUID uuid = UUID.randomUUID();
		 ReferenceID = uuid.toString();
		 } 
		 catch (Exception e) {
		 e.printStackTrace();
		 }
		 return ReferenceID;
		 }
	
}
